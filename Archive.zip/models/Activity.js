var bcrypt = require('bcrypt-nodejs');
var crypto = require('crypto');
var mongoose = require('mongoose');

var activitySchema = new mongoose.Schema({
  title: String, 
  slug: String, // used in URL, looks-like-this
  userId: Object,
  description: String,
  status: String, // e.g. active or inactive
  tags: Array,
  media: {
    img: {
      _default: String
    }
  }

  /*email: { type: String, unique: true, lowercase: true },
  password: String,
  isTourist: Boolean,
  isTourGuide: Boolean,

  facebook: String,
  twitter: String,
  google: String,
  github: String,
  instagram: String,
  linkedin: String,
  tokens: Array,

  profile: {
    name: { type: String, default: '' },
    gender: { type: String, default: '' },
    location: { type: String, default: '' },
    website: { type: String, default: '' },
    picture: { type: String, default: '' }
  },

  resetPasswordToken: String,
  resetPasswordExpires: Date*/
});


/**
 * Helper method for validationg user's password.
 */
/*
userSchema.methods.comparePassword = function(candidatePassword, cb) {
  bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
    if (err) { return cb(err); }
    cb(null, isMatch);
  });
};
*/

module.exports = mongoose.model('Activity', activitySchema);
