var Activity = require('../models/Activity');

/**
 * GET /experiences/all
 * Activities list all.
 */

exports.getAll = function(req, res) {

  Activity.find({}, function(err, activities) {
    if (err) return next(err);

    res.render('activity/all', {
    	title: 'All Experiences',
    	activities: activities
  	});
  });
};

/**
 * GET /view/id
 * Show experience page
 */

exports.getActivity = function(req, res) {

  var id = req.params.id;

  Activity.findById(id, function(err, activity) {
    if (err) return res.render('error/not-found');

    res.render('activity/index', {
      title: activity.title,
      activity: activity
    });
  });
};


/**
 * GET /experience/new
 * Add new experience form
 */
exports.getNewActivity = function(req, res) {
    res.render('activity/new', {
    	title: 'New Experience'
  	});
};



/**
 * POST /experience/new
 * Adds an experience
 * @param title
 * @param description
 * @param userId
 */

exports.postNewActivity = function(req, res) {
  req.assert('title', 'Title cannot be blank').notEmpty();
  req.assert('description', 'Description cannot be blank').notEmpty();

  var errors = req.validationErrors();

  if (errors) {
    req.flash('errors', errors);
    return res.redirect('/experience/new');
  }

  var title = req.body.title;
  var description = req.body.description;
  var userId = req.user._id;
  var status = req.body.status;
  var slug = makeSlug(title + " " + userId); // TODO change userId to datetime

  var activity = new Activity({
    title: title,
    slug: slug,
    description: description,
    userId: userId,
    status: status
  });

  activity.save(function(err, activity) {
    if (err) return next(err);
    return res.redirect('/view/'+activity.id);
  });

};



/**
 * GET /edit/aid
 * Edit an experience form
 */

exports.getUpdateActivity = function(req, res) {

  var id = req.params.id;

  Activity.findById(id, function(err, activity) {
    if (err || (activity.userId != req.user.id)) return res.render('error/not-found');

    res.render('activity/edit', {
      title: 'Edit '+ activity.title,
      activity: activity
    });
  });
};



/**
 * POST /edit/aid
 * Edits an experience
 * @param title
 * @param description
 * @param userId
 */

exports.postUpdateActivity = function(req, res) {
  var aid = req.params.id;

  Activity.findById(aid, function(err, activity) {

    if (err || (activity.userId != req.user.id) ) {
      req.flash('errors', { msg: 'Something went wrong' });
      return res.redirect('/');
    }

    activity.title = req.body.title;
    activity.description = req.body.description;
    activity.status = req.body.status;

    activity.save(function(err) {
      if (err) return next(err);
      req.flash('success', { msg: 'Experience updated.' });
      res.redirect('/edit/'+activity._id);
    });
  });
};


/**
 * makeSlug
 * Converts string to url-friendly-format
 * @param string
 */
function makeSlug(string) {
  return string
        .toLowerCase()
        .replace(/[^\w ]+/g,'')
        .replace(/ +/g,'-')
        ;
}